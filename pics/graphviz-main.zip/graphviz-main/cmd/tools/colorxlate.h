#pragma once

#include <cgraph/agxbuf.h>

void colorxlate(char *str, agxbuf *buf);
